# PredictBR — Prediction Market Platform

Clone do Polymarket construído com Next.js 14, Wagmi v2 e Polygon.

## Stack

- **Frontend**: Next.js 14 (App Router), TypeScript, Tailwind CSS
- **Web3**: Wagmi v2, Viem, WalletConnect v2
- **Gráficos**: Chart.js + react-chartjs-2
- **Blockchain**: Polygon PoS — contratos Gnosis CTF + CLOB
- **Banco**: PostgreSQL 16 com Row-Level Security (multi-tenant)
- **Cache / Realtime**: Redis Cluster + WebSocket (ws)
- **Eventos**: Apache Kafka
- **Séries temporais**: TimescaleDB
- **Oracle**: UMA Optimistic Oracle v3
- **Pagamentos**: Circle API (USDC) + Pix BR

## Estrutura

```
predictbr/
├── src/
│   ├── components/
│   │   ├── MarketCard.tsx        # Card de mercado na listagem
│   │   ├── MarketDetail.tsx      # Página de detalhe com order book
│   │   ├── OrderBook.tsx         # Book de ordens L2 em tempo real
│   │   ├── ProbabilityChart.tsx  # Gráfico de probabilidade histórica
│   │   ├── TradePanel.tsx        # Painel de compra/venda de shares
│   │   ├── Portfolio.tsx         # Portfólio e posições do usuário
│   │   └── Navbar.tsx            # Barra de navegação + wallet
│   ├── pages/
│   │   ├── index.tsx             # Listagem de mercados
│   │   ├── market/[id].tsx       # Detalhe de mercado
│   │   └── portfolio.tsx         # Portfólio
│   ├── lib/
│   │   ├── wagmi.ts              # Config Wagmi + WalletConnect
│   │   ├── contracts.ts          # ABIs e endereços dos contratos
│   │   ├── api.ts                # Cliente HTTP para a API REST
│   │   └── websocket.ts          # Cliente WebSocket para tempo real
│   ├── hooks/
│   │   ├── useMarkets.ts         # Busca e filtra mercados
│   │   ├── useOrderBook.ts       # Book de ordens em tempo real
│   │   ├── useTrade.ts           # Execução de trades on-chain
│   │   └── usePortfolio.ts       # Posições e PnL do usuário
│   └── styles/
│       └── globals.css           # Variáveis globais + Tailwind base
├── public/
│   └── favicon.svg
├── architecture/
│   ├── ARCHITECTURE.md           # Descrição completa da arquitetura
│   └── diagrams/
│       ├── overview.md           # Visão geral em camadas
│       ├── data-flow.md          # Fluxo de dados e eventos
│       └── smart-contracts.md    # Contratos e fluxo on-chain
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.js
```

## Início rápido

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Abrir no navegador
open http://localhost:3000
```

## Variáveis de ambiente

Crie um `.env.local` na raiz:

```env
NEXT_PUBLIC_WALLETCONNECT_PROJECT_ID=seu_id_aqui
NEXT_PUBLIC_ALCHEMY_KEY=sua_chave_aqui
NEXT_PUBLIC_API_URL=http://localhost:4000
DATABASE_URL=postgresql://user:pass@localhost:5432/predictbr
REDIS_URL=redis://localhost:6379
KAFKA_BROKERS=localhost:9092
CIRCLE_API_KEY=sua_chave_circle
```

## Arquitetura resumida

```
Cliente (Next.js)
    ↕ REST + WebSocket
API Gateway (Kong)
    ↕
Microsserviços (Go / Rust / Node.js)
  ├── Auth Service       (JWT + SIWE + KYC)
  ├── Market Service     (criação e resolução)
  ├── CLOB Engine        (matching de ordens — Rust)
  ├── Trading Service    (posições e PnL)
  ├── Oracle Service     (UMA + Chainlink)
  ├── Wallet Service     (USDC + Circle)
  └── Analytics Service  (Kafka → TimescaleDB)
    ↕
Polygon Blockchain
  ├── CTF Contracts (ERC-1155 shares)
  ├── CLOB Contract (settlement trustless)
  └── UMA Oracle    (resolução descentralizada)
```
