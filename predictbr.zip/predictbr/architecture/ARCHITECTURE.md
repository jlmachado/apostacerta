# Arquitetura — PredictBR

## Visão geral em camadas

```
┌─────────────────────────────────────────────────────────────────┐
│  CLIENTES                                                       │
│  Web App (Next.js 14)  │  Mobile (React Native)  │  Admin Panel│
└───────────────────────────────┬─────────────────────────────────┘
                                │ HTTPS / WSS
┌───────────────────────────────▼─────────────────────────────────┐
│  EDGE / GATEWAY                                                 │
│  CDN (Cloudflare WAF)  │  API Gateway (Kong)  │  WS Gateway    │
└───────────────────────────────┬─────────────────────────────────┘
                                │ gRPC / REST interno
┌───────────────────────────────▼─────────────────────────────────┐
│  MICROSSERVIÇOS CORE                                            │
│  Auth  │  Tenant  │  Market  │  CLOB Engine  │  Trading        │
│  Oracle/Resolution  │  Wallet & Funds  │  Analytics  │  Notify │
└──────┬───────────────────────────────────────────┬──────────────┘
       │ SQL / Redis                               │ RPC / Webhooks
┌──────▼──────────────────┐          ┌────────────▼───────────────┐
│  DADOS                  │          │  BLOCKCHAIN (Polygon)      │
│  PostgreSQL (RLS)       │          │  CTF Contracts (ERC-1155)  │
│  Redis Cluster          │          │  CLOB Contract (EIP-712)   │
│  Kafka                  │          │  UMA Oracle v3             │
│  TimescaleDB            │          │  USDC nativo               │
└─────────────────────────┘          └────────────────────────────┘
```

## Fluxo de trade (compra de shares YES)

```
1. Usuário digita valor no TradePanel (frontend)
2. Frontend assina a ordem via EIP-712 (Wagmi)
3. POST /v1/trades → API Gateway → Trading Service
4. Trading Service valida saldo e envia ao CLOB Engine (gRPC)
5. CLOB Engine (Rust) faz matching no order book em memória
6. Ordem executada → evento publicado no Kafka (tópico: trades)
7. Trading Service consome evento → atualiza posição no PostgreSQL
8. Wallet Service consome evento → chama CLOB Contract on-chain
9. Contrato valida assinatura EIP-712 e registra trade na blockchain
10. Analytics Service consome evento → atualiza TimescaleDB
11. WebSocket Gateway publica update para clientes conectados
```

## Isolamento multi-tenant (SaaS)

```
Camada      Mecanismo
─────────   ──────────────────────────────────────────────────────
Banco       Row-Level Security (RLS) por tenant_id em todas tabelas
Subdomínio  {slug}.predictbr.io → Tenant Service lê configurações
API         JWT com claim tenant_id validado em cada serviço
Blockchain  Cada tenant usa endereços de contrato isolados (futuro)
Billing     Stripe subscription por tenant, limites por plano
```

## Resolução de mercado (Oracle)

```
1. Data de encerramento chega (configurada no Market Service)
2. Oracle Service consulta fontes externas (Sportradar, AP, etc.)
3. Resultado submetido ao UMA Optimistic Oracle com bond de USDC
4. Período de contestação: 2 horas
   - Sem disputa → resultado aceito automaticamente
   - Com disputa → token holders de UMA votam (on-chain)
5. Resultado finalizado on-chain → evento emitido
6. Wallet Service monitora evento → chama redeemPositions no CTF
7. Holders de shares vencedores recebem USDC automaticamente
```

## Estimativa de escala inicial

| Componente     | Config sugerida                        |
|----------------|----------------------------------------|
| CLOB Engine    | 2× c6i.2xlarge (8 vCPU, 16 GB RAM)    |
| Microsserviços | Kubernetes EKS, HPA por CPU/RPS        |
| PostgreSQL     | RDS Postgres 16, db.r6g.xlarge + 2 réplicas |
| Redis          | ElastiCache Cluster, 3 nós r6g.large  |
| Kafka          | MSK 3 brokers kafka.m5.large           |
| TimescaleDB    | RDS Postgres + extensão TimescaleDB    |
| CDN            | Cloudflare Pro (WAF + DDoS inclusos)   |
