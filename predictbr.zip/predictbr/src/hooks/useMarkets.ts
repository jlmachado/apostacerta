import { useState, useEffect } from 'react'
import { getMarkets, type Market } from '@/lib/api'

export function useMarkets(category?: string, search?: string) {
  const [markets, setMarkets] = useState<Market[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    setLoading(true)
    getMarkets({ category: category === 'Todos' ? undefined : category, search })
      .then(setMarkets)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false))
  }, [category, search])

  return { markets, loading, error }
}
