import { useState, useEffect } from 'react'
import { useAccount } from 'wagmi'
import { getPortfolio, type Position } from '@/lib/api'

export function usePortfolio() {
  const { address } = useAccount()
  const [positions, setPositions] = useState<Position[]>([])
  const [totalValue, setTotalValue] = useState(0)
  const [totalPnl, setTotalPnl] = useState(0)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!address) return
    setLoading(true)
    getPortfolio(address)
      .then(({ positions, totalValue, totalPnl }) => {
        setPositions(positions)
        setTotalValue(totalValue)
        setTotalPnl(totalPnl)
      })
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [address])

  return { positions, totalValue, totalPnl, loading }
}
