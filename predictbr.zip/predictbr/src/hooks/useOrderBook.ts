import { useState, useEffect, useCallback } from 'react'
import { getOrderBook, type OrderBook } from '@/lib/api'
import { wsClient } from '@/lib/websocket'

const EMPTY: OrderBook = { bids: [], asks: [], spread: 0 }

export function useOrderBook(marketId: string) {
  const [book, setBook] = useState<OrderBook>(EMPTY)
  const [loading, setLoading] = useState(true)

  const refresh = useCallback(() => {
    getOrderBook(marketId)
      .then(setBook)
      .catch(console.error)
      .finally(() => setLoading(false))
  }, [marketId])

  useEffect(() => {
    refresh()
    wsClient.connect()
    wsClient.subscribe(marketId)

    const handler = (ev: Parameters<Parameters<typeof wsClient.addListener>[0]>[0]) => {
      if (ev.type === 'orderbook' && ev.marketId === marketId) {
        setBook(b => ({ ...b, bids: ev.bids as any, asks: ev.asks as any }))
      }
    }

    wsClient.addListener(handler)
    return () => {
      wsClient.removeListener(handler)
      wsClient.unsubscribe(marketId)
    }
  }, [marketId, refresh])

  return { book, loading, refresh }
}
