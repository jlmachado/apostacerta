import { useState } from 'react'
import { useAccount, useSignTypedData } from 'wagmi'
import { submitTrade } from '@/lib/api'

type Side = 'BUY' | 'SELL'
type Outcome = 'YES' | 'NO'

export function useTrade() {
  const { address } = useAccount()
  const { signTypedDataAsync } = useSignTypedData()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function trade(params: {
    marketId: string
    outcome: Outcome
    side: Side
    amount: number
    limitPrice?: number
  }) {
    if (!address) throw new Error('Carteira não conectada')
    setLoading(true)
    setError(null)

    try {
      // Assinar a ordem via EIP-712 antes de enviar para o CLOB
      const signature = await signTypedDataAsync({
        domain: {
          name: 'PredictBR CLOB',
          version: '1',
          chainId: 137, // Polygon
          verifyingContract: '0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E',
        },
        types: {
          Order: [
            { name: 'marketId', type: 'string' },
            { name: 'outcome',  type: 'string' },
            { name: 'side',     type: 'string' },
            { name: 'amount',   type: 'uint256' },
            { name: 'nonce',    type: 'uint256' },
          ],
        },
        primaryType: 'Order',
        message: {
          marketId:  params.marketId,
          outcome:   params.outcome,
          side:      params.side,
          amount:    BigInt(Math.round(params.amount * 1e6)), // USDC 6 decimais
          nonce:     BigInt(Date.now()),
        },
      })

      return await submitTrade({
        ...params,
        walletAddress: address,
        signature,
      })
    } catch (e: any) {
      setError(e.message)
      throw e
    } finally {
      setLoading(false)
    }
  }

  return { trade, loading, error }
}
