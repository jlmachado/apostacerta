'use client'
import { useState } from 'react'
import MarketCard from '@/components/MarketCard'
import { useMarkets } from '@/hooks/useMarkets'

const CATS = ['Todos', 'Esportes', 'Cripto', 'Política', 'Finanças', 'Tecnologia']

export default function Home() {
  const [cat, setCat] = useState('Todos')
  const [search, setSearch] = useState('')
  const { markets, loading } = useMarkets(cat, search)

  return (
    <main>
      <div className="px-4 py-3 border-b border-gray-100 flex flex-col gap-3">
        <input
          className="w-full px-3 py-2 rounded-lg border border-gray-200 text-[13px] text-gray-900 outline-none focus:border-gray-300 bg-gray-50 placeholder:text-gray-400"
          placeholder="Buscar mercados..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        <div className="flex gap-1.5 flex-wrap">
          {CATS.map(c => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`px-3 py-1 rounded-full text-[12px] border transition-colors ${
                cat === c
                  ? 'bg-purple-50 border-purple-200 text-purple-800'
                  : 'border-gray-200 text-gray-500 hover:bg-gray-50'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 p-4">
        {loading
          ? Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="border border-gray-100 rounded-xl p-3 bg-white animate-pulse">
                <div className="h-3 bg-gray-100 rounded w-16 mb-3" />
                <div className="h-4 bg-gray-100 rounded w-full mb-2" />
                <div className="h-4 bg-gray-100 rounded w-3/4 mb-4" />
                <div className="h-1 bg-gray-100 rounded mb-2" />
                <div className="h-4 bg-gray-100 rounded w-20" />
              </div>
            ))
          : markets.map(m => <MarketCard key={m.id} market={m} />)
        }
        {!loading && markets.length === 0 && (
          <p className="col-span-full text-center text-gray-400 text-[14px] py-16">Nenhum mercado encontrado.</p>
        )}
      </div>
    </main>
  )
}
