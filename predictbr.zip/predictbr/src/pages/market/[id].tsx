'use client'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import { getMarket, type Market } from '@/lib/api'
import ProbabilityChart from '@/components/ProbabilityChart'
import OrderBook from '@/components/OrderBook'
import TradePanel from '@/components/TradePanel'

const CAT_COLORS: Record<string, string> = {
  Esportes:   'bg-emerald-50 text-emerald-800 border-emerald-200',
  Cripto:     'bg-amber-50 text-amber-800 border-amber-200',
  Política:   'bg-purple-50 text-purple-800 border-purple-200',
  Finanças:   'bg-blue-50 text-blue-800 border-blue-200',
  Tecnologia: 'bg-orange-50 text-orange-800 border-orange-200',
}

function fmtVol(v: number) {
  return v >= 1e6 ? `$${(v / 1e6).toFixed(1)}M` : `$${(v / 1e3).toFixed(0)}K`
}

export default function MarketPage() {
  const router = useRouter()
  const { id } = router.query
  const [market, setMarket] = useState<Market | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id || typeof id !== 'string') return
    getMarket(id).then(setMarket).catch(console.error).finally(() => setLoading(false))
  }, [id])

  if (loading) return <div className="p-8 text-center text-gray-400 text-[14px]">Carregando...</div>
  if (!market) return <div className="p-8 text-center text-gray-400 text-[14px]">Mercado não encontrado.</div>

  const yp = Math.round(market.yesPrice * 100)
  const catCls = CAT_COLORS[market.category] ?? 'bg-gray-50 text-gray-700 border-gray-200'

  return (
    <main>
      <button onClick={() => router.back()} className="px-4 py-2.5 text-[13px] text-gray-400 hover:text-gray-700 border-b border-gray-100 w-full text-left transition-colors">
        ← Voltar aos mercados
      </button>

      <div className="px-4 py-3 border-b border-gray-100">
        <h1 className="text-[16px] font-medium text-gray-900 leading-snug mb-2">{market.question}</h1>
        <div className="flex items-center gap-3 flex-wrap text-[12px]">
          <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${catCls}`}>{market.category}</span>
          <span className="text-emerald-600 font-medium">{yp}% SIM</span>
          <span className="text-red-400">{100 - yp}% NÃO</span>
          <span className="text-gray-400">{fmtVol(market.volume)}</span>
          <span className="text-gray-400">Encerra: {market.endDate}</span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row">
        <div className="flex-1 p-4 border-b lg:border-b-0 lg:border-r border-gray-100 space-y-5">
          <ProbabilityChart marketId={market.id} currentProb={yp} />
          <div className="border-t border-gray-100 pt-4">
            <OrderBook marketId={market.id} yesProb={yp} />
          </div>
        </div>
        <div className="lg:w-64 p-4">
          <TradePanel market={market} />
        </div>
      </div>
    </main>
  )
}
