const BASE = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000'

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  })
  if (!res.ok) throw new Error(`API error ${res.status}: ${await res.text()}`)
  return res.json()
}

// ── Markets ──────────────────────────────────────────────────────────────
export type Market = {
  id: string
  question: string
  category: string
  yesPrice: number
  noPrice: number
  volume: number
  liquidity: number
  endDate: string
  status: 'active' | 'resolved' | 'closed'
  resolvedOutcome?: 'YES' | 'NO'
}

export const getMarkets = (params?: { category?: string; search?: string }) =>
  req<Market[]>('/v1/markets?' + new URLSearchParams(params as Record<string,string>))

export const getMarket = (id: string) =>
  req<Market>(`/v1/markets/${id}`)

// ── Order Book ────────────────────────────────────────────────────────────
export type OrderBookLevel = { price: number; size: number; total: number }
export type OrderBook = { bids: OrderBookLevel[]; asks: OrderBookLevel[]; spread: number }

export const getOrderBook = (marketId: string) =>
  req<OrderBook>(`/v1/markets/${marketId}/orderbook`)

// ── Trades ────────────────────────────────────────────────────────────────
export type TradePayload = {
  marketId: string
  outcome: 'YES' | 'NO'
  side: 'BUY' | 'SELL'
  amount: number
  limitPrice?: number
  walletAddress: string
  signature: string
}

export const submitTrade = (payload: TradePayload) =>
  req<{ orderId: string; txHash?: string }>('/v1/trades', {
    method: 'POST',
    body: JSON.stringify(payload),
  })

// ── Portfolio ──────────────────────────────────────────────────────────────
export type Position = {
  marketId: string
  question: string
  outcome: 'YES' | 'NO'
  shares: number
  avgPrice: number
  currentPrice: number
  invested: number
  currentValue: number
  pnl: number
  pnlPct: number
}

export const getPortfolio = (address: string) =>
  req<{ positions: Position[]; totalValue: number; totalPnl: number }>(
    `/v1/portfolio/${address}`
  )
