type WSEvent =
  | { type: 'orderbook'; marketId: string; bids: Level[]; asks: Level[] }
  | { type: 'trade';     marketId: string; price: number; size: number; side: 'BUY' | 'SELL' }
  | { type: 'price';     marketId: string; yesPrice: number; noPrice: number }

type Level = { price: number; size: number }
type Listener = (event: WSEvent) => void

class WSClient {
  private ws: WebSocket | null = null
  private listeners = new Set<Listener>()
  private subs = new Set<string>()
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null

  connect() {
    if (this.ws?.readyState === WebSocket.OPEN) return
    const url = (process.env.NEXT_PUBLIC_WS_URL ?? 'ws://localhost:4001') + '/ws'
    this.ws = new WebSocket(url)

    this.ws.onopen = () => {
      this.subs.forEach(id => this.send({ action: 'subscribe', marketId: id }))
    }

    this.ws.onmessage = (ev) => {
      try {
        const data: WSEvent = JSON.parse(ev.data)
        this.listeners.forEach(fn => fn(data))
      } catch {}
    }

    this.ws.onclose = () => {
      this.reconnectTimer = setTimeout(() => this.connect(), 3000)
    }
  }

  private send(payload: unknown) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload))
    }
  }

  subscribe(marketId: string) {
    this.subs.add(marketId)
    this.send({ action: 'subscribe', marketId })
  }

  unsubscribe(marketId: string) {
    this.subs.delete(marketId)
    this.send({ action: 'unsubscribe', marketId })
  }

  addListener(fn: Listener) { this.listeners.add(fn) }
  removeListener(fn: Listener) { this.listeners.delete(fn) }

  disconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer)
    this.ws?.close()
  }
}

export const wsClient = new WSClient()
