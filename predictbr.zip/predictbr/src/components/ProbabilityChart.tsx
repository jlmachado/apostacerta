'use client'
import { Line } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale, LinearScale, PointElement, LineElement,
  Tooltip, Filler,
} from 'chart.js'
import { useState, useMemo } from 'react'

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Filler)

type Range = '1D' | '7D' | '30D'

interface Props {
  marketId: string
  currentProb: number
}

function generateHistory(prob: number, steps: number, seed: number): number[] {
  let v = Math.max(5, Math.min(95, prob + ((seed * 7 + 3) % 30) - 15))
  const arr: number[] = []
  for (let i = steps; i >= 0; i--) {
    const n = Math.sin(i * seed * 0.31) * 3.8 + Math.cos(i * 0.73) * 2.2
    v += n * 0.45 + (prob - v) * 0.04
    v = Math.max(2, Math.min(98, v))
    arr.push(Math.round(v * 10) / 10)
  }
  arr[arr.length - 1] = prob
  return arr
}

const RANGE_STEPS: Record<Range, number> = { '1D': 24, '7D': 56, '30D': 120 }

export default function ProbabilityChart({ marketId, currentProb }: Props) {
  const [range, setRange] = useState<Range>('30D')
  const seed = parseInt(marketId, 16) || 42

  const data = useMemo(
    () => generateHistory(currentProb, RANGE_STEPS[range], seed),
    [currentProb, range, seed]
  )

  const labels = data.map((_, i) => {
    const steps = RANGE_STEPS[range]
    if (range === '1D') return i % 6 === 0 ? `${i}h` : ''
    if (range === '7D') return i % 8 === 0 ? `d${Math.ceil((steps - i) / 8)}` : ''
    return i % 15 === 0 ? `${Math.ceil((steps - i) / 4)}d` : ''
  })

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-[10px] font-medium uppercase tracking-widest text-gray-400">Probabilidade</p>
        <div className="flex gap-1">
          {(['1D', '7D', '30D'] as Range[]).map(r => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={`px-2 py-0.5 rounded text-[11px] border transition-colors ${
                range === r
                  ? 'bg-gray-100 text-gray-900 border-gray-200'
                  : 'text-gray-400 border-transparent hover:border-gray-100'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>
      <div className="h-36">
        <Line
          data={{
            labels,
            datasets: [{
              data,
              borderColor: '#1D9E75',
              borderWidth: 1.5,
              pointRadius: 0,
              tension: 0.35,
              fill: false,
            }],
          }}
          options={{
            responsive: true,
            maintainAspectRatio: false,
            animation: false,
            plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } },
            scales: {
              x: { grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { color: '#9ca3af', font: { size: 10 }, maxRotation: 0 }, border: { display: false } },
              y: { min: 0, max: 100, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { color: '#9ca3af', font: { size: 10 }, callback: v => `${v}%` }, border: { display: false } },
            },
          }}
        />
      </div>
    </div>
  )
}
