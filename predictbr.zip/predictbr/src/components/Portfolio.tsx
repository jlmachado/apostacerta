'use client'
import { usePortfolio } from '@/hooks/usePortfolio'
import { useAccount } from 'wagmi'
import Link from 'next/link'

export default function Portfolio() {
  const { isConnected } = useAccount()
  const { positions, totalValue, totalPnl, loading } = usePortfolio()

  if (!isConnected) {
    return (
      <div className="text-center py-20 text-gray-400 text-[14px]">
        Conecte sua carteira para ver seu portfólio.
      </div>
    )
  }

  if (loading) {
    return <div className="text-center py-20 text-gray-400 text-[14px]">Carregando...</div>
  }

  return (
    <div className="p-4">
      {/* Stats */}
      <div className="flex gap-6 pb-4 border-b border-gray-100 mb-4 flex-wrap">
        <div>
          <div className="text-[22px] font-medium text-gray-900">${totalValue.toFixed(2)}</div>
          <div className="text-[11px] text-gray-400 mt-0.5">Valor do portfólio</div>
        </div>
        <div>
          <div className={`text-[22px] font-medium ${totalPnl >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
            {totalPnl >= 0 ? '+' : ''}{totalPnl.toFixed(2)} USDC
          </div>
          <div className="text-[11px] text-gray-400 mt-0.5">Lucro / Perda</div>
        </div>
        <div>
          <div className="text-[22px] font-medium text-gray-900">{positions.length}</div>
          <div className="text-[11px] text-gray-400 mt-0.5">Posições abertas</div>
        </div>
      </div>

      {/* Positions */}
      {positions.length === 0 ? (
        <div className="text-center py-16 text-gray-400 text-[14px] leading-relaxed">
          Nenhuma posição ainda.<br />
          <Link href="/" className="text-[#7F77DD] hover:underline">Explore os mercados</Link> e faça sua primeira aposta.
        </div>
      ) : (
        <div className="space-y-2">
          {positions.map((pos, i) => (
            <Link
              key={i}
              href={`/market/${pos.marketId}`}
              className="flex items-start gap-3 p-3 border border-gray-100 rounded-xl hover:border-gray-200 transition-colors"
            >
              <span className={`text-[11px] font-medium px-2 py-0.5 rounded-full flex-shrink-0 ${
                pos.outcome === 'YES'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : 'bg-orange-50 text-orange-800 border border-orange-200'
              }`}>
                {pos.outcome === 'YES' ? 'SIM' : 'NÃO'}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-[12px] text-gray-900 leading-snug mb-1 line-clamp-2">{pos.question}</p>
                <p className="text-[11px] text-gray-400">
                  {pos.shares.toFixed(2)} shares @ {(pos.avgPrice * 100).toFixed(1)}¢
                </p>
              </div>
              <div className={`text-[12px] font-medium flex-shrink-0 ${pos.pnl >= 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                {pos.pnl >= 0 ? '+' : ''}${pos.pnl.toFixed(2)}
                <br />
                <span className="text-[10px]">({pos.pnlPct >= 0 ? '+' : ''}{pos.pnlPct.toFixed(1)}%)</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
