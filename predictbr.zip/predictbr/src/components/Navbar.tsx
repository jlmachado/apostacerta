'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useAccount, useConnect, useDisconnect, useBalance } from 'wagmi'
import { injected } from 'wagmi/connectors'
import { CONTRACTS } from '@/lib/contracts'

export default function Navbar() {
  const pathname = usePathname()
  const { address, isConnected } = useAccount()
  const { connect } = useConnect()
  const { disconnect } = useDisconnect()
  const { data: balance } = useBalance({ address, token: CONTRACTS.USDC })

  const short = address ? `${address.slice(0, 6)}...${address.slice(-4)}` : ''

  return (
    <nav className="flex items-center gap-2 px-4 py-2.5 border-b border-gray-100 bg-white sticky top-0 z-50 flex-wrap">
      <Link href="/" className="flex items-center gap-2 mr-2 font-medium text-[15px] text-gray-900">
        <span className="w-2.5 h-2.5 rounded-full bg-[#7F77DD]" />
        PredictBR
      </Link>

      <Link
        href="/"
        className={`px-3 py-1 rounded-lg text-[13px] transition-colors ${
          pathname === '/' ? 'bg-gray-100 text-gray-900 font-medium' : 'text-gray-500 hover:bg-gray-50'
        }`}
      >
        Mercados
      </Link>
      <Link
        href="/portfolio"
        className={`px-3 py-1 rounded-lg text-[13px] transition-colors ${
          pathname === '/portfolio' ? 'bg-gray-100 text-gray-900 font-medium' : 'text-gray-500 hover:bg-gray-50'
        }`}
      >
        Portfólio
      </Link>

      <div className="ml-auto flex items-center gap-2">
        {isConnected && balance && (
          <span className="text-[12px] font-medium px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200">
            {parseFloat(balance.formatted).toFixed(2)} USDC
          </span>
        )}
        {isConnected ? (
          <button
            onClick={() => disconnect()}
            className="text-[12px] px-3 py-1.5 rounded-lg border border-gray-200 text-gray-700 hover:bg-gray-50 transition-colors"
          >
            {short}
          </button>
        ) : (
          <button
            onClick={() => connect({ connector: injected() })}
            className="text-[12px] px-3 py-1.5 rounded-lg bg-[#7F77DD] text-white font-medium hover:bg-[#534AB7] transition-colors"
          >
            Conectar carteira
          </button>
        )}
      </div>
    </nav>
  )
}
