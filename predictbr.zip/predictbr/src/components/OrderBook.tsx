'use client'
import { useOrderBook } from '@/hooks/useOrderBook'

export default function OrderBook({ marketId, yesProb }: { marketId: string; yesProb: number }) {
  const { book } = useOrderBook(marketId)

  const asks = book.asks.length > 0 ? book.asks : generateLevels(yesProb / 100, 'ask')
  const bids = book.bids.length > 0 ? book.bids : generateLevels(yesProb / 100, 'bid')

  return (
    <div>
      <p className="text-[10px] font-medium uppercase tracking-widest text-gray-400 mb-2">
        Book de ordens — YES shares
      </p>
      <div className="grid grid-cols-3 text-[10px] text-gray-400 mb-1 px-0.5">
        <span>Preço</span><span className="text-center">Qtd.</span><span className="text-right">Total</span>
      </div>
      {asks.map((r, i) => (
        <div key={i} className="grid grid-cols-3 text-[11px] py-0.5 px-0.5 rounded hover:bg-gray-50 cursor-default">
          <span className="text-red-500 font-medium">{(r.price * 100).toFixed(1)}¢</span>
          <span className="text-center text-gray-600">{r.size.toLocaleString('pt-BR')}</span>
          <span className="text-right text-gray-400">{Math.round(r.price * r.size)}</span>
        </div>
      ))}
      <div className="text-center text-[11px] font-medium text-gray-500 py-1 border-y border-gray-100 my-1">
        {yesProb}% — spread: {(book.spread * 100 || 1.2).toFixed(1)}¢
      </div>
      {bids.map((r, i) => (
        <div key={i} className="grid grid-cols-3 text-[11px] py-0.5 px-0.5 rounded hover:bg-gray-50 cursor-default">
          <span className="text-emerald-600 font-medium">{(r.price * 100).toFixed(1)}¢</span>
          <span className="text-center text-gray-600">{r.size.toLocaleString('pt-BR')}</span>
          <span className="text-right text-gray-400">{Math.round(r.price * r.size)}</span>
        </div>
      ))}
    </div>
  )
}

function generateLevels(p: number, side: 'ask' | 'bid') {
  return Array.from({ length: 5 }, (_, i) => {
    const offset = (i + 1) * 0.012
    const price = side === 'ask'
      ? Math.min(0.99, p + offset)
      : Math.max(0.01, p - offset)
    const size = Math.round(400 + Math.random() * 2000)
    return { price, size, total: Math.round(price * size) }
  })
}
