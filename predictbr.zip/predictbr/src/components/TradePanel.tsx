'use client'
import { useState } from 'react'
import { useAccount } from 'wagmi'
import { useTrade } from '@/hooks/useTrade'
import type { Market } from '@/lib/api'

type Outcome = 'YES' | 'NO'
type TrType = 'buy' | 'sell'

export default function TradePanel({ market }: { market: Market }) {
  const { isConnected } = useAccount()
  const { trade, loading } = useTrade()
  const [trType, setTrType] = useState<TrType>('buy')
  const [outcome, setOutcome] = useState<Outcome>('YES')
  const [amount, setAmount] = useState('')
  const [toast, setToast] = useState('')

  const yp = market.yesPrice
  const np = 1 - yp
  const price = outcome === 'YES' ? yp : np
  const amt = parseFloat(amount) || 0
  const shares = amt > 0 ? amt / price : 0
  const profit = shares - amt

  function notify(msg: string) {
    setToast(msg)
    setTimeout(() => setToast(''), 3000)
  }

  async function exec() {
    if (!isConnected) return notify('Conecte sua carteira para continuar.')
    if (amt <= 0) return notify('Insira um valor.')
    try {
      await trade({ marketId: market.id, outcome, side: trType === 'buy' ? 'BUY' : 'SELL', amount: amt })
      notify(`${shares.toFixed(2)} shares ${outcome} ${trType === 'buy' ? 'comprados' : 'vendidos'}!`)
      setAmount('')
    } catch (e: any) {
      notify(e.message)
    }
  }

  return (
    <div className="relative">
      {/* Buy / Sell toggle */}
      <div className="flex rounded-lg border border-gray-200 overflow-hidden mb-3">
        {(['buy', 'sell'] as TrType[]).map(t => (
          <button
            key={t}
            onClick={() => setTrType(t)}
            className={`flex-1 py-1.5 text-[13px] font-medium transition-colors ${
              trType === t ? 'bg-gray-100 text-gray-900' : 'text-gray-400 hover:bg-gray-50'
            }`}
          >
            {t === 'buy' ? 'Comprar' : 'Vender'}
          </button>
        ))}
      </div>

      {/* YES / NO */}
      <div className="flex gap-2 mb-3">
        <button
          onClick={() => setOutcome('YES')}
          className={`flex-1 py-1.5 rounded-lg text-[13px] font-medium border transition-all ${
            outcome === 'YES'
              ? 'bg-emerald-500 border-emerald-500 text-white'
              : 'border-emerald-200 text-emerald-700 hover:bg-emerald-50'
          }`}
        >
          SIM
        </button>
        <button
          onClick={() => setOutcome('NO')}
          className={`flex-1 py-1.5 rounded-lg text-[13px] font-medium border transition-all ${
            outcome === 'NO'
              ? 'bg-orange-500 border-orange-500 text-white'
              : 'border-orange-200 text-orange-700 hover:bg-orange-50'
          }`}
        >
          NÃO
        </button>
      </div>

      {/* Amount */}
      <p className="text-[11px] text-gray-400 mb-1">Valor (USDC)</p>
      <input
        type="number"
        value={amount}
        onChange={e => setAmount(e.target.value)}
        placeholder="0,00"
        className="w-full px-3 py-2 rounded-lg border border-gray-200 text-[13px] text-gray-900 outline-none focus:border-emerald-400 mb-2 bg-gray-50"
      />
      <div className="flex gap-1 mb-3">
        {[10, 25, 50, 100].map(v => (
          <button
            key={v}
            onClick={() => setAmount(String(v))}
            className="flex-1 py-1 rounded border border-gray-200 text-[11px] text-gray-500 hover:bg-gray-50 transition-colors"
          >
            ${v}
          </button>
        ))}
      </div>

      {/* Summary */}
      <div className="bg-gray-50 rounded-lg p-3 mb-3 space-y-1">
        <div className="flex justify-between text-[12px]">
          <span className="text-gray-400">Preço unitário</span>
          <span className="font-medium text-gray-900">{(price * 100).toFixed(1)}¢</span>
        </div>
        <div className="flex justify-between text-[12px]">
          <span className="text-gray-400">Shares estimados</span>
          <span className="font-medium text-gray-900">{amt > 0 ? shares.toFixed(2) : '—'}</span>
        </div>
        <div className="flex justify-between text-[12px]">
          <span className="text-gray-400">Potencial lucro</span>
          <span className="font-medium text-emerald-600">{amt > 0 ? `+${profit.toFixed(2)} USDC` : '—'}</span>
        </div>
      </div>

      {/* CTA */}
      <button
        onClick={exec}
        disabled={loading}
        className={`w-full py-2.5 rounded-xl text-[14px] font-medium text-white transition-opacity disabled:opacity-60 ${
          outcome === 'YES' ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-orange-500 hover:bg-orange-600'
        }`}
      >
        {loading ? 'Aguardando...' : `${trType === 'buy' ? 'Comprar' : 'Vender'} ${outcome === 'YES' ? 'SIM' : 'NÃO'}`}
      </button>

      {/* Toast */}
      {toast && (
        <div className="absolute bottom-14 left-0 right-0 flex justify-center">
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-2 text-[13px] text-gray-800 shadow-sm">
            {toast}
          </div>
        </div>
      )}
    </div>
  )
}
