import Link from 'next/link'
import type { Market } from '@/lib/api'

const CAT_COLORS: Record<string, string> = {
  Esportes:   'bg-emerald-50 text-emerald-800 border-emerald-200',
  Cripto:     'bg-amber-50 text-amber-800 border-amber-200',
  Política:   'bg-purple-50 text-purple-800 border-purple-200',
  Finanças:   'bg-blue-50 text-blue-800 border-blue-200',
  Tecnologia: 'bg-orange-50 text-orange-800 border-orange-200',
}

function fmtVol(v: number) {
  return v >= 1e6 ? `$${(v / 1e6).toFixed(1)}M` : `$${(v / 1e3).toFixed(0)}K`
}

export default function MarketCard({ market }: { market: Market }) {
  const yp = Math.round(market.yesPrice * 100)
  const np = 100 - yp
  const catCls = CAT_COLORS[market.category] ?? 'bg-gray-50 text-gray-700 border-gray-200'

  return (
    <Link
      href={`/market/${market.id}`}
      className="block border border-gray-100 rounded-xl p-3 bg-white hover:-translate-y-0.5 hover:border-gray-200 transition-all duration-100"
    >
      <div className="flex items-center justify-between mb-2">
        <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${catCls}`}>
          {market.category}
        </span>
        <span className="text-[10px] text-gray-400">Ativo</span>
      </div>

      <p className="text-[13px] font-medium text-gray-900 leading-snug mb-3 min-h-[40px]">
        {market.question}
      </p>

      <div className="h-1 bg-gray-100 rounded-full mb-2 overflow-hidden">
        <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${yp}%` }} />
      </div>

      <div className="flex items-baseline justify-between">
        <div>
          <span className="text-[15px] font-medium text-emerald-600">{yp}% SIM</span>
          <span className="text-[11px] text-gray-400 ml-1">{np}% NÃO</span>
        </div>
        <span className="text-[11px] text-gray-400">Vol: {fmtVol(market.volume)}</span>
      </div>
    </Link>
  )
}
